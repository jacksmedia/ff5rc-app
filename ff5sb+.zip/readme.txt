This work is for

"HatZen08's FF5 Strategic Battle" v3.1 (2021)

and this patch must be applied AFTER

you patch your ROM with that patch.

https://www.romhacking.net/hacks/5955/

(Please note that it expects a headered base ROM.)

------

WHAT THESE DO:

--4 New Abilities Names.ips--

Gives the 4 new Abilities unique names, and descriptions.

Mantra -->  Uplift
Add 1 to level in battle. Stackable

Observe --> Secure
Gain Armor and Shell statuses

Analyze --> Bright
Gain Wall and Haste statuses. Wall is temporary

Slash --> Strike
Damage equals Max HP - HP



--FFVPR Ability Names.ips--
Does what "4 New Abilities Names.ips" does.

ALSO changes many Ability names to match the modern FFV names as closely as possible (as seen in "FFV: Pixel Remaster").

Only use this if you dislike the classic fan translation names for the Abilities. If you prefer "Combine" to "Mix" and "Dimen" to "Time" then ignore this patch.

BuildUp --> Focus
Capture --> Mug
DrgnSwd --> Lance
X-Attack --> Rapid
Conjure --> Call
Combine --> Mix
Pray --> Recover
Terrain --> Gaia
Dimen --> Time
X-Magic --> 2x Cast
Brawl --> Barehand
Dbl Grip --> 2-Handed
2-Handed --> 2x Wield
Medicine --> Pharmacy
Barrier --> MgcShell
Caution --> Vigilance
Preemptiv --> FirstStk
Pitfalls --> FindPits
DmgFloor --> LightStp
Agility --> Artful
Dash --> Sprint

DmMgc --> Time

------
These patches also remove the ROM header.
LunarIPS always does this, so apologies if this bothers you. Feel free to put a copier header back on if you want. (Here is a great Windows tool to do that: https://www.romhacking.net/utilities/1638/ )

------
Stay tuned for more addenda to this great FFV mod.

- xJ4cks, 2025
https://www.notion.so/xj4cks/FF5-Mods-Review-2d56bad3142980598a61f2797c67305c