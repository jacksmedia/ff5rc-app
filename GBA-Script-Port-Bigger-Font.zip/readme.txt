FFV GBA Script Port - Bigger Font
---------------------------------
This is a simple and humble project that makes the font
seen in battle and when talking bigger.

Please use this patch after you use J121's work here:

https://www.romhacking.net/hacks/3687/

This is only an addendum to that Port, and it won't work
correctly without it!

Thanks to Gens for creating the awesome font used in this,
and for teaching me a lot about fine-tuning the spacing of
letters and symbols.

Thanks to noisecross for creating an awesome Text Editor;
this would not be possible without it!

Read much more about this here:

https://www.notion.so/xj4cks/GBA-Script-notes-mods-39ede0b6e7514b8892b6fccccb1c0208

-----------------------
January 2026, by xJ4cks