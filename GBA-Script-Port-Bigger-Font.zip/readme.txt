FFV GBA Script Port - Bigger Font v1.01
---------------------------------
This is a simple and humble project that makes the font
seen in battle and when talking bigger.

Please use this patch after you use J121's work here:

https://www.romhacking.net/hacks/3687/

This is only an addendum to that Port, and it won't work
correctly without it!

Thanks to Gens for creating the awesome font used in this,
and for teaching me a lot about fine-tuning the spacing of
letters and symbols.

Thanks to noisecross for creating an awesome Text Editor;
this would not be possible without it!

Read much more about this here:

https://www.notion.so/xj4cks/GBA-Script-notes-mods-39ede0b6e7514b8892b6fccccb1c0208

Thanks to AstroTibs for reporting the missing "?" bugs, and the issues with 
over-long battle messages, and capital I and lowercase L muddling. Some of these are 
still present (see the changelog) but will be fixed ASAP.

-----------------------
May 2026, by xJ4cks

-----------------------
Changelog:
30 May, 2026

Fixed the "?" getting replaced with "<>" (diamond icon) issue the Blue Magic menus.


11 February, 2026

Fixed a bug in the opening scene when the automatic dialog would stall 
after Faris spoke until the player pressed "A". This scene is meant to 
be precisely timed with the music so this was extremely suboptimal.