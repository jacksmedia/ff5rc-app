These sprites were created by "MtFujiInMyPants". They based these on the PSP FFIV sprite style, and devoted a LOT of time to this!

I discovered the links to their project on this thread:
https://www.reddit.com/r/FinalFantasy/comments/57kgoy/ffv_pc_psp_style_sprites_project_update/

While it seems like they did make a Steam mod for the 2015 iOS version of Final Fantasy V, I've found no record of these getting used in other projects.

If you use these for modding, give credit to the author!