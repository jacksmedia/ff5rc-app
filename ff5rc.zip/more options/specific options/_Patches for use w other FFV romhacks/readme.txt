Patches for use with other FFV romhacks
---------------------------------------

Start Encounters by Cubear

This gives the "Start" button a feature outside of battle. If your party is on a map that has monster encounters, you can push Start and force a fight! This is really helpful if you're farming for items to Steal or Blue Magic to Learn.


FF5 -- Active ATB Menu (by RoSoDude)

Makes battle flow more natural on Active mode.

https://romhackplaza.org/romhacks/ff5-active-atb-menu-snes/


FF5 -- Berserker ATB Fixes (by RoSoDude)

Makes Berserker Job behave more normally in battle.

https://romhackplaza.org/romhacks/ff5-berserker-atb-fixes-snes/