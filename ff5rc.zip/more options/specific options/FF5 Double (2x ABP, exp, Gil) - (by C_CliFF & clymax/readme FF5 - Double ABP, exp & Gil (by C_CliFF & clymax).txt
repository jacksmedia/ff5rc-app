FF5r 2x - by C_CliFF & clymax
------------------------------
Created for Final Fantasy 5 by C_CliFF, adjusted by clymax.

The rom must be unheadered.

"This is a simple patch that doubles EXP, Gil, and ABP to halve grinding."

Apply the "ff5_dbl_xp_gold_abp_unheadered (by C_CliFF).ips" patch to your rom first.

Then apply the "Final Fantasy V (Japan) [En by RPGe v1.1] (FF5 Double EXP, Gold and ABP 1.0 by C_CliFF) (bugfixes 1.2 by clymax).ips" patch.