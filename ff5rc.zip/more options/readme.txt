Apply any of these AFTER the main FF5r Clean patch.

These are upgrades, not full romhack patches.