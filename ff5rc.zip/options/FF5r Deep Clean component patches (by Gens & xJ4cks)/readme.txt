These 3 patches create the changes seen in the
"Deep Clean" version of this rommhack.

If you want to remove 1 or 2 of them to make an
even more custom experience, use the REMOVE patch
and it will return the game's code to the original
bytes, resetting them and removing that feature.

Thanks to Blade (Potato) and hakumen99 for help playtesting
this project, and for suggesting these REMOVE options!